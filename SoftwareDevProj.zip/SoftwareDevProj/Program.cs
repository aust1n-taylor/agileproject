﻿using System;
using System.Collections.Generic;
using System.Linq;

class Program
{
    static void Main(string[] args)
    {
        List<InventoryItem> inventory = new List<InventoryItem>();

        inventory.Add(new InventoryItem("Amphetamine", 0));
        inventory.Add(new InventoryItem("Anesthesia", 0));
        inventory.Add(new InventoryItem("Antibiotics", 0));
        inventory.Add(new InventoryItem("Asprin", 0));
        inventory.Add(new InventoryItem("Calcium Chloride", 0));
        inventory.Add(new InventoryItem("Covid Tests", 0));
        inventory.Add(new InventoryItem("Fentanyl", 0));
        inventory.Add(new InventoryItem("Ibuprofen", 0));
        inventory.Add(new InventoryItem("Morphine", 0));
        inventory.Add(new InventoryItem("Oxycodone", 0));


        Console.WriteLine("Inventory Report");
        Console.WriteLine("----------------");

        foreach (var item in inventory)
        {
            Console.WriteLine("{0} - {1} units", item.Name, item.Quantity);
        }

        Console.ReadLine();
    }
}

class InventoryItem
{
    public string Name { get; set; }
    public int Quantity { get; set; }

    public InventoryItem(string name, int quantity)
    {
        Name = name;
        Quantity = quantity;
    }
}
